import mitdeeplearning.util

import mitdeeplearning.lab1
import mitdeeplearning.lab2
import mitdeeplearning.lab3
import mitdeeplearning.lab3_old
